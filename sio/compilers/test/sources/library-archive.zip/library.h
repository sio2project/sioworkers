
#ifdef __cplusplus
extern "C" {
#endif

void HelloWorld();

#ifdef __cplusplus
}
#endif
